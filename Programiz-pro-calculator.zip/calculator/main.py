def add(a, b):
  return(a + b)
def subtract(a, b):
  return(a - b)
def multiply(a, b):
  return(a * b)
def divide(a, b):
  if b == 0:
    return("C'mon! really brother?")
  return(a / b)

print("select operation")
print("1")
print("2")
print("3")
print("4")
choice = input("enter choice(1/2/3/4)")

num1 = float(input("enter first number:"))
num2 = float(input("enter second number:"))

if choice == "1":
  print("result" , add(num1, num2))
elif choice == "2":
  print("result" , subtract(num1, num2))
elif choice == "3":
  print("result" , multiply(num1, num2))
elif choice == "4":
  print("result" , divide(num1, num2))
else:
  print("Check your emotions, pal!")

